## 1.1.0

* Add support for SonarQube 7.8

## 1.0.2

* Fix excessive memory use by MySQL driver

## 1.0.1

* Add support for SonarQube 6.7.7

## 1.0.0

* First release

[Unreleased]: https://github.com/SonarSource/mysql-migrator/compare/1.0.2.108...HEAD
[1.0.2]: https://github.com/SonarSource/mysql-migrator/tree/1.0.2.108
[1.0.1]: https://github.com/SonarSource/mysql-migrator/tree/1.0.1.102
[1.0.0]: https://github.com/SonarSource/mysql-migrator/tree/1.0.0.89
